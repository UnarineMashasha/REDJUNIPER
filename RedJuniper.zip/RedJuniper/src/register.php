<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>RED JUNIPER | Login and Registration</title>
        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
       <!-- <?php
            session_start();
             $first_name = $_POST['first_name'];
             $last_name = $_POST['last_name'];
             $user_name = $_POST['user'];
             $email = $_POST['email'];
             $pass = $_POST['pass'];
             $password = $_POST['password'];

             $resp = $obj -> add_user($first_name, $last_name, $user_name, $email, $pass, $password);
			echo $resp;

           // function add_user($first_name, $last_name, $user_name, $email, $pass, $password){
            //    include('connection.php');
            
               
            
                //$req=$db->prepare('INSERT INTO login_user (first_name, last_name, user_name, email, pass, password) VALUES(?,?,?,?,?,?)');
                //  $req->execute(array($first_name,$last_name,$user_name, $email, $pass, $password));
            
                 // if ($req -> rowCount() > 0) {
                    // code...
                 //   return 202;
                 // }else{
                //    return 303;
                //  }
                //  $req->closecursor();
             // }
        ?> --->
    </head>
    <body>
       
        <div class="hero">
            <div class="form-box">
                <!--<div class="button-box">
                    <div id="btn"></div>
                    <button type="button" class="toggle-btn" onclick="login()">Login</button>
                    <button type="button" class="toggle-btn" onclick="register()">Register</button> 
                </div>-->
                <div class="social-icons">
                    <i class="bi bi-facebook"></i>
                    <i class="bi bi-google"></i>
                </div>
              
                <form id="register" class="input-group" method="post">
                    <input type="text" id="first_name" class="input-field" placeholder="First Name" required>
                    <input type="text" id="last_name" class="input-field" placeholder="Last Name" required>
                    <input type="text" id="user" class="input-field" placeholder="Username" required>
                    <input type="email" id="email" class="input-field" placeholder="Email Address" required>
                    <input type="password" id="pass" class="input-field" placeholder="Enter password" required onkeyup="passwordStrength(this.value)" />
                    <input type="password" id="password" class="input-field" placeholder="Confirm password" value="" required/>
                    <input type="checkbox" class="check-box" name="checkbox">
                    <label for="checkbox">I agree with the Terms and Conditions</label>
                    <button type="submit" name="submit" class="submit-btn">Register</button>
                    <a href="login.php">Already have an account?</a>
                </form>
            </div>
        </div>
        <script src="main.js"></script>
        <style>
            .form-box{
                width: 380px;
                height:550px;
                font-family: 'Poppins', sans-serif;
                position: relative;
                margin: 6% auto;
                background: rgb(226, 226, 226);
                padding: 5px;
                overflow: hidden;
                box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
                border-radius: 3px;
                overflow: hidden;
            }
            .hero{
            height:100%;
            width: 100%;
            background-position: center;
            background-image: linear-gradient( rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.3)), url(../assets/background-login.jpg);
            background-size: cover;
            position: absolute;
            }
            .form-box{
            width: 680px;
            height:550px;
            font-family: 'Poppins', sans-serif;
            position: relative;
            margin: 6% auto;
            background: rgb(226, 226, 226);
            padding: 5px;
            overflow: hidden;
            box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
            border-radius: 3px;
            overflow: hidden;
            }
            .button-box{
            width: 228px;
            margin: 35px auto;
            position: relative;
            box-shadow: 0 0 20px 9px #ff61241b;
            border-radius: 30px;
            }

            .toggle-btn{
            padding: 10px 30px;
            cursor: pointer;
            background: transparent;
            border: 0;
            outline: none;
            position: relative;
            }
            #btn{
            top: 0;
            left: 0;
            position: absolute;
            width: 110px;
            height: 100%;
            background: linear-gradient(to right, #ff4b2b, #ff416d);
            border-radius: 50px;
            transition: .5s;
            -webkit-border-radius: 50px;
            -moz-border-radius: 50px;
            -ms-border-radius: 50px;
            -o-border-radius: 50px;
            -webkit-transition: .5s;
            -moz-transition: .5s;
            -ms-transition: .5s;
            -o-transition: .5s;
            }

            .social-icons{
            margin: 30px auto;
            text-align: center;
            }
            .social-icons i{
            width:35px;
            margin: 0 12px;
            box-shadow: 0 0 20px 0 #7f7f7f3d;
            cursor: pointer;
            border-radius: 50%;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            -o-border-radius: 50%;
            }

            .input-group{
            top: 145px;
            margin-left: 185px;
            position:absolute;
            width: 280px;
            transition: .5s;
            
            }
            a{
                font-family:"Poppins", sans-serif;
                text-decoration: none;
                color: #000;
            }
            .input-field{
            width: 100%;
            padding: 10px 0;
            margin: 5px 0;
            border-top: 0;
            border-left: 0;
            border-right: 0;
            border-bottom: 1px solid #999;
            outline: none;
            background: transparent;
            }
            .submit-btn{
            width:85%;
            padding: 10px 30px;
            cursor:pointer;
            display: block;
            margin:auto;
            background: linear-gradient(to right, #ff4b2b, #ff416c);
            border: 0;
            outline: none;
            border-radius: 30px;
            }
            .check-box{
            margin: 30px 3px 30px 0;
            }

            label{
            color:#777;
            font-size:12px;
            bottom:68px;
            }

            /*#login{
            left: 50px;

            }*/
            
            #register .input-group{
            top: 280px;
            }
        </style>
    </body>
</html>