<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="login_user";
	$conn = mysqli_connect($servername, $username, $password,$db);
?>