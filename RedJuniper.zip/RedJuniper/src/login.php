<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>RED JUNIPER | Login and Registration</title>
        <link rel="stylesheet" href="Style.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <?php
            session_start();;
        ?>
    </head>
    <body>
    
        <div class="hero">
            <div class="form-box">
                <div class="button-box">
                    <div id="btn"></div>
                    <button type="button" class="toggle-btn" onclick="login()">Login</button>
                    <button type="button" class="toggle-btn" onclick="register()">Register</button>  
                </div>
                <div class="social-icons">
                    <i class="bi bi-facebook"></i>
                    <i class="bi bi-google"></i>
                </div>
                <form id="login" class="input-group" method="post">
                    
                    <input type="text" id="username" class="input-field" placeholder="Username" required>
                    <input type="password" id="password" class="input-field" placeholder="Enter password" required>
                    <input type="checkbox" name="checkbox" class="check-box">
                    <label for="checkbox">Remember password</label>
                    <button type="submit" class="submit-btn">Login</button>
                </form>
                <form id="register" class="input-group" method="post">
                    <input type="text" id="first_name" class="input-field" placeholder="First Name" required>
                    <input type="text" id="last_name" class="input-field" placeholder="Last Name" required>
                    <input type="text" id="user" class="input-field" placeholder="Username" required>
                    <input type="email" id="email" class="input-field" placeholder="Email Address" required>
                    <input type="password" id="pass" class="input-field" placeholder="Enter password" required onkeyup="passwordStrength(this.value)" />
                    <input type="password" id="password" class="input-field" placeholder="Confirm password" value="" required/>
                    <input type="checkbox" class="check-box" name="checkbox">
                    <label for="checkbox">I agree with the Terms and Conditions</label>
                    <button type="submit" name="submit" class="submit-btn">Register</button>
                    <a href="login.php">Already have an account?</a>
                </form>
            </div>
        </div>
        <script src="main.js"></script>
    </body>
</html>